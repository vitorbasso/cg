import pygame

pygame.init()
Screen_Width = 800
Screen_Height = 600

colorPalet = {
    'black': (0, 0, 0),
    'gray': (192, 192, 192),
    'maroon': (128, 0, 0),
    'red': (255, 0, 0),
    'green': (0, 128, 0),
    'lime': (0, 255, 0),
    'olive': (102, 102, 0),
    'yellow': (255, 255, 0),
    'navy': (0, 0, 102),
    'blue': (0, 0, 255),
    'purple': (128, 0, 128),
    'fuchsia': (255, 0, 128),
    'teal': (0, 128, 128),
    'aqua': (0, 255, 255),
    'silver': (192, 192, 192),
    'white': (255, 255, 255)
}



